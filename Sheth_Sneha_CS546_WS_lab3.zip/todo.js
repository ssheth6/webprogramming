const mongoCollections = require("./mongoCollections");
const uuid = require("node-uuid");
const todoItems = mongoCollections.todoItems;

let todoMethods = 
{
    getTask(id) 
    {
        if (!id)
        {
            return Promise.reject("You must provide an id to search for");
        }
            
        return todoItems().then((taskCollection) => 
        {
            if(!taskCollection.findOne({_id: id}) || taskCollection.findOne({_id: id}) === undefined)
            {
                return Promise.reject("Task with the given id does not exist.");
            }
            return taskCollection.findOne({_id: id});
        });
    },

    createTask(title, description)
    {
        if (!title || !description)
        {
            return Promise.reject("You must provide a title and description for your todo list.");
        }
        return todoItems().then((taskCollection) => 
        {
            let newTask = 
            {
                _id: uuid.v4(),
                title: title,
                description: description,
                completed: false,
                completedAt: null
            };

            return taskCollection.insertOne(newTask)
                .then((newInsertInformation) => 
                {
                    return newInsertInformation.insertedId;
                })
                .then((newId) => {
                    return this.getTask(newId);
                });
        });
    },

    getAllTasks()
    {
        return todoItems().then((taskCollection) => 
        {
            var myCursor = taskCollection.find();
            var documentArray = myCursor.toArray();
            if(!documentArray)
            {
                return Promise.reject("No tasks exist.");
            }
            return documentArray;
        });
        
    },

    completeTask(taskId)
    {
        if (!taskId || taskId === undefined)
        {
            return Promise.reject("You must provide an id to search for");
        }
        return todoItems().then((taskCollection) => 
        {
            return taskCollection
            .updateOne({_id: taskId}, {$set:{"completed" : "true", "completedAt" : new Date().toTimeString().split(" ")[0]}})
            .then(() => 
            {
                return this.getTask(taskId);
            });
        });
    },

    removeTask(id)
    {
        if (!id || id === undefined)
        {
            return Promise.reject("You must provide an id to search for");
        } 

        return todoItems().then((taskCollection) => 
        {
            return taskCollection
                .remove({_id: id})
                .then((deletionInfo) => 
                {
                    if (deletionInfo.deletedCount === 0) 
                    {
                        return Promise.reject(`Could not delete task with id of ${id}`);
                    }
                });
        });
    }

}

module.exports = todoMethods;