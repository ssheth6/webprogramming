const todoItems = require("./todo");
const connection = require("./mongoConnection");


let firstCreatedTask = todoItems.createTask("Ponder Dinosaurs", "Has Anyone Really Been Far Even as Decided to Use Even Go Want to do Look More Like?");
let secondCreatedTask = todoItems.createTask("Play Pokemon with Twitch TV", "Should we revive Helix?");

//add first task
firstCreatedTask.then((firstNewTask) => 
{
    console.log("First Task inserted is:");
    console.log(firstNewTask); //log first task

    //add second task
    secondCreatedTask.then((secondNewTask) =>
    {
        console.log("Second Task inserted is:");
        console.log(secondNewTask);

        //query and log all tasks
        let myAllTasks = todoItems.getAllTasks();
        myAllTasks.then((myAllTasksArray) => 
        {
            console.log("All tasks in the document are:");
            console.log(myAllTasksArray);

            //remove first task
            let removeFirstTask = todoItems.removeTask(myAllTasksArray[0]._id);
            removeFirstTask.then(() =>
            {
                console.log("The first task has been removed.");
            }).catch((error) =>
            {
                console.log(error);
                console.error("Could not remove task or no task exists.");
            });

            //query and log remaining tasks
            let getAllTasksAgain = todoItems.getAllTasks();
            getAllTasksAgain.then((myNewAllTasksArray) => 
            {
                console.log("All tasks in the document after removing the first one are:");
                console.log(myNewAllTasksArray);

                //complete remaining tasks
                let completeRemainingTask;
                console.log("The completed remaining tasks are:");
                for(let i=0; i < myNewAllTasksArray.length; i++)
                {
                    completeRemainingTask = todoItems.completeTask(myNewAllTasksArray[i]._id);
                    completeRemainingTask.then((task) =>
                    {
                        console.log(task); //log remaining task

                    }).catch((error) =>
                    {
                        console.log(error);
                        console.error("Could not find or complete task.");
                    });
                }
                //close db connection
                completeRemainingTask.catch().then(() => 
                {
                    return connection();
                }).then((db) => 
                {
                    return db.close();
                });
                
            }).catch((error) =>
            {
                console.log(error);
                console.error("Could not find all tasks again or no task exists.");
            });

        }).catch((error) =>
        {
            console.log(error);
            console.error("Could not find all tasks or no task exists.");
        });

    }).catch((error) =>
    {
        console.log(error);
        console.error("Could not insert second task.");
    });

}).catch((error) =>
{
    console.log(error);
    console.error("Could not insert first task.");
});





