const fs = require('fs');
const path = __dirname + "/notes.json"

let read = () => 
{
	return new Promise((resolve, reject) => 
    {
		fs.readFile(path, 'utf8', function(error, data) 
        {
			if (error) 
            {
				reject(error); 
				return;
			}
			var note = JSON.parse(data);
			resolve(note);
		});
	})
}

let write = (data) => 
{
	return new Promise((resolve, reject) => 
    {
		data = JSON.stringify(data, null, 4);
		fs.writeFile(path, data, function(error) 
        {
			if (error) 
            {
				reject(error);
				return;
			}
			resolve("file saved\n" + data);
		});
	})
}

module.exports = 
{
	read: read,
	write: write
}



