const readWrite = require('./readAndWrite')
let currentId = 2;
let noteEntries = {};
readWrite.read().then(obj => 
{
    noteEntries = obj;
    currentId = Object.keys(noteEntries.notes).length;
})



let compareDueDates = (a, b) => 
{
    return a.due_date > b.due_date;
}

let getNumberOfTasks = () =>
{
    return currentId;
}

let addNotes = (title, due_date, summary, body) =>
{
    let newNote = 
    {
        id: currentId++,
        title: title,
        due_date: due_date,
        summary: summary,
        body: body
    };
    noteEntries.notes.push(newNote);
    noteEntries.notes.sort(compareDueDates);
    for (let i = 1; i <= currentId; i++) 
    {
        noteEntries.notes[i - 1].id = i;
    }

    readWrite.write(noteEntries).then(res => 
    {
        Promise.resolve(res); 
    })

    return newNote;
};

let getNotes = (id) =>
{
    if (!noteEntries.notes[id - 1]) Promise.reject("No such entry exists");
    return noteEntries.notes[id - 1];
};

let getAllNotes = () => 
{
    return noteEntries.notes;
};

module.exports = 
{
    getNumberOfTasks: getNumberOfTasks,
    getNotes: getNotes,
    getAllNotes: getAllNotes,
    addNotes: addNotes
};










