const express = require('express');
const router = express.Router();
const xss = require('xss');
const data = require('../data/index')

router.get("/", (request, response) => 
{

	response.render("notes/new", {});

})

router.get("/:note", (request, response) => 
{
	response.render("notes/notes", 
    {
		note: data.getNotes(request.params.note)
	});

})

router.post("/", (request, response) =>
{

	let requestBody = request.body;
	let newNote = data.addNotes(xss(requestBody.title), xss(requestBody.due), xss(requestBody.summary), xss(requestBody.body));

	response.status(200).send(newNote);
});

router.post("/nextNote", (request, response) => 
{
	let requestBody = request.body;
	let id;
	try 
	{
		if (parseInt(requestBody.id) >= parseInt(data.getNumberOfTasks())) 
		{
			id = 1;
		} 
		else 
		{
			id = parseInt(requestBody.id) + 1;
		}
	} 
	catch (error) 
	{
		console.log(error);
	}
	let note = data.getNotes(id);
	response.status(200).json(note);
})

module.exports = router;

