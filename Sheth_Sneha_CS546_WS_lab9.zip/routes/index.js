const newNotes = require("./notes");
const notesData = require('../data');

const constructorMethod = (app) => 
{
    app.use("/new", newNotes);

    app.get("/", function (request, response) 
    {
        response.render("notes/home", { noteItems: notesData.getAllNotes()});
    });

    app.use("*", (req, res) => 
    {
        res.sendStatus(404);
    })
};

module.exports = constructorMethod;