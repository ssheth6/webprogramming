(function($) 
{
    var myNewNoteForm = $("#new-note-form"),
        noteTitle = $("#new-note-title"),
        noteSummary = $("#new-note-summary"),
        noteDue = $("#new-note-due"),
        noteBody = $("#new-note-body");

    myNewNoteForm.submit(function(event) 
    {

        event.preventDefault();
        var newNoteTitle = noteTitle.val();
        var newNoteDue = noteDue.val();
        var newNoteSummary = noteSummary.val();
        var newNoteBody = noteBody.val();
        var newContent = $("#new-notes");

        if (!newNoteTitle || !newNoteSummary || !newNoteDue || !newNoteBody) 
        {
           $('#alert').removeClass('hidden');
            return;
        }
        var requestConfig = 
        {
            method: "POST",
            url: "/new",
            contentType: 'application/json',
            data: JSON.stringify(
            {
                title: newNoteTitle,
                due: newNoteDue,
                summary: newNoteSummary,
                body: newNoteBody
            })
        };
        $.ajax(requestConfig).then(function(responseMessage) 
        {
            console.log(responseMessage);
            window.location.href = "http://localhost:3000/new/" + responseMessage.id;
        });
    });

    let nextButton = $('#nextBtn');
    let title = $('#title');
    let dueDate = $('#dueDate');
    let summary = $('#summary');
    let body = $('#noteBody');
    let id = $('#noteId');

    nextButton.click(() => 
    {
        var requestConfig = 
        {
            method: "POST",
            url: "/new/nextNote",
            contentType: 'application/json',
            data: JSON.stringify(
            {
                id: parseInt(id.text()[id.text().length - 1])
            })
        };
        $.ajax(requestConfig).then(function(res) 
        {
            title.text("Note Title: " + res.title);
            dueDate.text("Note Due Date: " + res.due_date);
            summary.html("Note Summary: " + res.summary);
            body.html("Note Body: " + res.body);
            id.text("Note ID: " + res.id);

            window.location.href = "http://localhost:3000/new/"+res.id;
        });
    })
})(window.jQuery);

