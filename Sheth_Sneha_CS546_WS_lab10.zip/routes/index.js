const LocalStrategy = require('passport-local').Strategy;
const path = require('path');
const login = require('../data/');
const passport = require('passport');

let configPassport = (passport) => 
{
	passport.use(new LocalStrategy((username, password, done) =>
        {
            let validateUser = login.verifyUserPass(username, password);

			if (validateUser.status)
                return done(null, validateUser.message);
				
			return done(null, false, 
            {
				message: validateUser.message
			});
	    }
	));

	passport.serializeUser((user, done) => 
    {
		done(null, user);
	});

	passport.deserializeUser((user, done) => 
    {
		let authenticate = user.split(' ');
		if (authenticate.length != 2)
			return done(null, false, {
				message: "Cookie is not valid"
			});

		let username = authenticate[0];
		let password = authenticate[1];

		let validateUser = login.verifyUserPass(username, password);

		if (validateUser.status)
            return done(null, validateUser.message);

		return done(null, false, {
			message: validateUser.message
		});
	});
}

configPassport(passport);

const constructorMethod = (app) =>
{
    app.use(passport.initialize());
	app.use(passport.session());

    app.post('/login', passport.authenticate('local', 
    {
        successRedirect: '/private',
        failureRedirect: '/',
        failureFlash: true,
        successFlash: 'Welcome, you have logged in successfully!'
    }));

    app.get('/private', (request, response) => 
    {
        if (request.isAuthenticated()) 
        {
            let username = request.user.split(' ')[0];
            let userInformation = login.getUserById(username);
            response.render('private.handlebars', 
            {
                username: username,
                alias: userInformation.alias,
                firstName: userInformation.firstName,
                lastName: userInformation.lastName,
                profession: userInformation.profession,
                bio: userInformation.bio
            });
        } 
        else 
        {
            response.redirect(301, '/login');
        }

    })

    app.get('/login', (request, response) => 
    {
		if (!request.isAuthenticated()) 
        {
			if (request.session.flash && request.session.flash.error) 
            {
                console.log("Error: " + request.session.flash.error.slice(-1)[0]);
				response.render('loginform.handlebars', 
                {
					error: true,
					message: request.session.flash.error.slice(-1)[0]
				});
				return
			}
			response.render('loginform.handlebars', {
				error: false
			});
		} 
        else 
        {
			response.redirect(301, '/private/');
		}
	});

    app.get("/", (request, response) =>
    {
        console.log(request.session);
        if (request.isAuthenticated()) 
        {
			response.redirect(301, '/private/');
		} 
        else 
        {
			response.redirect(301, '/login/')
		}
    });

    app.use("*", (request, response) => 
    {
        response.sendStatus(404);
    })
};

module.exports = constructorMethod;