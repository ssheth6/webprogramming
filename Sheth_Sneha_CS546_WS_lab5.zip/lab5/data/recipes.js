const mongoCollections = require("../config/mongoCollections");
const recipes = mongoCollections.recipes;
const uuid = require('node-uuid');
const commentsData = require('./comments');

let exportedMethods = {

    //This function returns recipe by id.
    getRecipeById(id) 
    {
        return recipes().then((recipeCollection) => 
        {
            return recipeCollection.findOne({_id: id})
            .then((recipe) => 
            {
                    if (!recipe) 
                        return Promise.reject("No recipe found!");
                    return recipe;
            });
        })
        .catch((err) => 
        {
            console.error(err);
            throw err;
        });
    },

    //Returns all the specifications of a particular reccipe.
    getDetailsOfRecipeById(id)
    {
        return this.getRecipeById(id).then(recipe => 
        {
            return recipe;
        })
        .then((recipe) => 
        {
            if (!recipe) 
                return Promise.reject("No recipe found!");
            return commentsData.getCommentsByRecipeId(id).then(comments => 
            {
                recipe.comments = comments;
                return recipe;
            });
        }).catch(err => 
        {
            console.log(err);
            throw err;
        });
    },

    //This function returns all recipes.
    getAllRecipes() 
    {
        return recipes().then((recipeCollection) => 
        {
            return recipeCollection.find({}).toArray();
        });
    },



    //This function adds a new rcipe to the list.
    addRecipe(title, ingredients, steps) 
    {
        if (typeof title !== "string") 
            return Promise.reject("Please provide a title");

        //Get all ingredients from the array
        if (!Array.isArray(ingredients)) 
        {
            ingredients = [];
        }
        //Get all the steps from the Array
        if (!Array.isArray(steps)) 
        {
            steps = [];
        }

        
        return recipes().then((recipeCollection) => 
        {
                let newRecipe = 
                {
                    title: title,
                    ingredients: ingredients,
                    steps: steps,
                    comments: [],
                    _id: uuid.v4()
                };

                return recipeCollection
                    .insertOne(newRecipe)
                    .then((newInsertInformation) => 
                    {
                        return newInsertInformation.insertedId;
                    })
                    .then((newId) => 
                    {
                        return this.getRecipeById(newId);
                    });
		});
    },

    
    //saves updates for a particualr recipe
    updateRecipes(id, updatedRecipe) 
    {
        return recipes().then((recipeCollection) => 
        {
            let updatedRecipeData = {};

            if (updatedRecipe.title) 
            {
                updatedRecipeData.title = updatedRecipe.title;
            }

            if (updatedRecipe.ingredients) 
            {
                updatedRecipeData.ingredients = updatedRecipe.ingredients;
            }

            if (updatedRecipe.body) 
            {
                updatedRecipeData.steps = updatedRecipe.steps;
            }

            let updateCommand = 
            {
                $set: updatedRecipeData
            };

            return recipeCollection.updateOne({
                _id: id
            }, updateCommand).then((result) => 
            {
                return this.getRecipeById(id);
            });
        });
    },

    
    //Remove recipe by id
    removeRecipebyId(id) 
    {
        return recipes().then((recipeCollection) => 
        {
            return recipeCollection
                .removeOne({_id: id})
                .then((deletionInfo) => 
                {
                    if (deletionInfo.deletedCount === 0) 
                    {
                        return Promise.reject(`Recipe with the id ${id} cannot be deleted`);
                    } 
                    else 
                    {
                        return true;
                    }
                });
        });
    }
}

module.exports = exportedMethods;

