const mongoCollections = require("../config/mongoCollections");
const comments = mongoCollections.comments;
const uuid = require('node-uuid');

let exportedMethods = {

    //This function returns comments by id.
    getCommentsById(id) 
    {
        return comments().then((commentCollection) => 
        {
            return commentCollection.findOne({_id: id})
                .then((comment) => 
                {
                    if (!comment) 
                        return Promise.reject("No comments found!");
                    return comment;
                });
        });
    },

    //This function adds new comments.
    addComment(recipeId, comments, poster) 
    {
        if (typeof recipeId !== "string") 
            return Promise.reject("recipeId not provided");

        if (typeof comment !== "string") 
            return Promise.reject("Comments not Provided");

        if (typeof poster !== "string") 
            return Promise.reject("Poster not provided");
        
        return comments().then((commentsCollection) => 
        {

                    let newComment = 
                    {
                        recipeId: recipeId,
                        comments: comments,
                        poster: poster,
                        _id: uuid.v4()
                    };

                    return commentsCollection
                        .insertOne(newComment)
                        .then((newInsertInformation) => 
                        {
                            return newInsertInformation.insertedId;
                        })
                        .then((newId) => 
                        {
                            return this.getCommentsById(newId);
                        });
		});
    },

    //This function fetches comments by recipe id.
    getCommentsByRecipeId(recipeId) 
    {
        return comments().then((commentCollection) => 
        {
            return commentCollection.find({recipeId:recipeId}).toArray();
        });
    },
    
    //This function removes comments by recipe id.
    removeCommentByRecipeId(recipeId) 
    {
        return comments().then((commentCollection) => 
        {
            return commentCollection
                .removeOne({recipeId: recipeId})
                .then((deletionInfo) => 
                {
                    if (deletionInfo.deletedCount === 0) 
                    {
                        throw(`comment with id ${id} cannot be deleted`);
                    } 
                    else 
                    {
                        return true;
                    }
                });
        });
    },

    //This function updates comments by id and the updated comment.
    updateComments(id, updatedComment) 
    {
        return comments().then((commentCollection) => 
        {
            let updatedCommentData = {};

            if (updatedComment.comment) 
            {
                updatedCommentData.comment = updatedComment.comment;
            }

            if (updatedComment.poster) 
            {
                updatedCommentData.poster = updatedComment.poster;
            }


            let updateCommand = 
            {
                $set: updatedCommentData
            };

            return commentCollection.updateOne({
                _id: id
            }, updateCommand).then((result) => 
            {
                return this.getCommentsById(id);
            });
        });
    },

    //This function removes comments by id.
    removeComments(id) {
        return comments().then((commentCollection) => 
        {
            return commentCollection
                .removeOne({_id: id})
                .then((deletionInfo) => 
                {
                    if (deletionInfo.deletedCount === 0) 
                    {
                        throw(`comment with id ${id} cannot be deleted`)
                    } 
                    else 
                    {
                        return true;
                    }
                });
        });
    },
}

module.exports = exportedMethods;
