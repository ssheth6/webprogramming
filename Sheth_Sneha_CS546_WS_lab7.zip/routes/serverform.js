const express = require('express');
const router = express.Router();
const data = require("../data");

const form = data.form;

router.get("/",(req,res) => 
{
    res.render("form/serverform",{});
});

router.post("/",(req,res) => 
{
    let textArea = req.body.textArea;
    let stringInput = req.body.stringInput;
    let firstNumber = req.body.number1;
    let secondNumber = req.body.number2;
    
    let output;
    try
    {
        if(firstNumber < 1 || firstNumber > 25 || secondNumber < 1 || secondNumber > 25)
        {
            throw "Number less than 1 and greater than 25 is not allowed!";
        }

        if(!textArea) 
        {
            throw "No content for the text area!";
        }
        
        if(!stringInput)
        {
            throw "No content for the string input!";
        }

        output = form.textManipulation(textArea, stringInput, firstNumber, secondNumber)
    }
    catch(e)
    {
        res.render("form/serverform", {textArea: textArea, stringInput: stringInput, number1: firstNumber, number2: secondNumber, error: e});
        return;
    }

    res.render("form/serverform", {textArea: textArea, stringInput: stringInput, number1: firstNumber, number2: secondNumber, result: output});
});
module.exports = router;