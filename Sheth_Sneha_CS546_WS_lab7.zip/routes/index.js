const serverFormRoutes=require("./serverform");
const clientFormRoutes=require("./clientform");

const constructorMethod = (app) => 
{
    app.use("/serverform",serverFormRoutes);
    app.use("/clientform",clientFormRoutes);
    
    app.use("*", (req, res) => 
    {
        res.redirect("clientform");
    })
};

module.exports = constructorMethod;