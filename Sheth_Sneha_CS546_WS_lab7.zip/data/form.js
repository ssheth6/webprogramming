let exportedMethods = 
{
    textManipulation(textArea, stringInput, number1, number2)
    {
        var result = "";
        let temp = textArea.match(new RegExp('.{1,'+number2+'}','g'));
        for(let i=0; i < number1; i++)
        {
            temp[i] = temp[i] + stringInput;
        }
        for(let j=0; j < temp.length; j++)
        {
            result = result + temp[j];
        }
        return result;
    }
}
module.exports = exportedMethods;


