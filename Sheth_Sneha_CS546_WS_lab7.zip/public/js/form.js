(function () 
{
    function textManipulation(textArea, stringInput, firstNumber, secondNumber)
    {
        if(firstNumber < 1 || firstNumber > 25 || secondNumber < 1 || secondNumber > 25)
        {
            throw "Number less than 1 and greater than 25 is not allowed!";
        }

        if(!textArea) 
        {
            throw "No content for the text area!";
        }
        
        if(!stringInput)
        {
            throw "No content for the string input!";
        }
        var result = "";
        let temp = textArea.match(new RegExp('.{1,'+secondNumber+'}','g'));
        for(let i=0; i < firstNumber; i++)
        {
            temp[i] = temp[i] + stringInput;
        }
        for(let j=0; j < temp.length; j++)
        {
            result = result + temp[j];
        }
        return result;
    }

    var staticForm = document.getElementById("static-form");

    if (staticForm) {
        // We can store references to our elements; it's better to 
        // store them once rather than re-query the DOM traversal each time
        // that the event runs.
        var stringInputElement = document.getElementById("stringInput");
        var textAreaElement = document.getElementById("textArea");
        var firstNumberElement = document.getElementById("number1");
        var secondNumberElement = document.getElementById("number2");
        

        var errorContainer = document.getElementById("error-container");
        var errorTextElement = errorContainer.getElementsByClassName("text-goes-here")[0];

        var resultContainer = document.getElementById("result-container");
        var resultTextElement = resultContainer.getElementsByClassName("text-goes-here")[0];

        // We can take advantage of functional scoping; our event listener has access to its outer functional scope
        // This means that these variables are accessible in our callback
        staticForm.addEventListener("submit", function (event) {
            event.preventDefault();

            try {
                // hide containers by default
                errorContainer.classList.add("hidden");
                resultContainer.classList.add("hidden");

                // Values come from inputs as strings, no matter what :(
                var stringInputValue = stringInputElement.value;
                var textAreaElementValue = textAreaElement.value;
                var firstNumberValue = firstNumberElement.value;
                var secondNumberValue = secondNumberElement.value;
                


                var parsedFirstNumberValue = parseInt(firstNumberValue);
                var parsedSecondNumberValue = parseInt(secondNumberValue);
                var result = textManipulation(textAreaElementValue, stringInputValue, parsedFirstNumberValue, parsedSecondNumberValue);
                resultTextElement.textContent = "The result is:\n\n\n" +result;
                resultContainer.classList.remove("hidden");
            } catch (e) {
                var message = typeof e === "string" ? e : e.message;
                errorTextElement.textContent = e;
                errorContainer.classList.remove("hidden");
            }
        });
    }
})();