const express = require('express');
const router = express.Router();
const data = require("../data");
const path = require('path');
const peopleData = data.people;
const eventsData = data.events;
const locationsData = data.locations;

// Single Person Page
router.get("/:id", (req, res) => 
{
    peopleData.getPerson(Number(req.params.id)).then(person => 
    {
        return person;
    })
    .then((person) => 
    {
        return eventsData.getEventsForAttendee(Number(person.id)).then(eventList => 
        {
	    	        return [person,eventList];
        });
    })
    .then(generalList => 
    {
            res.render('people/one', {person: generalList[0], eventList: generalList[1]});
    })
    .catch((error) => 
    {
        console.log(error);
    	let route = path.resolve(`static/about.html`);
        res.sendFile(route);
    });

});

// People Index Page
router.get("/", (req, res) => 
{
    peopleData.getAllPeople()
    .then((people) => 
    {
        res.render('people/everything', {people: people })
    })
    .catch(() => 
    {
        res.status(404).json({ error: "Event not found" });
    });
});

module.exports = router;