const express = require('express');
const router = express.Router();
const data = require("../data");
const path = require('path');
const eventsData = data.events;
const locationsData = data.locations;
const peopleData = data.people;

// Single Location Page
router.get("/:id", (req, res) => 
{
    locationsData.getLocation(Number(req.params.id)).then(locationList => 
    {
    	eventsData.getAllEvents().then(events => 
        {
    		let eventsAtLocation = events.filter(event => event.location == locationList.id);
    		res.render('locations/one', {location: locationList, eventsAtLocation: eventsAtLocation});
    	})
        .catch((error) => 
        {
            console.log(error);
        });
    }).catch((error) => 
    {
        console.log(error);
        let route = path.resolve(`static/about.html`);
        res.sendFile(route);
    });
    
});

// Location Index Page
router.get("/", (req, res) => 
{
    locationsData.getAllLocations().then(allLocations => 
    {
    	res.render('locations/everything', {allLocations: allLocations});
    })
    .catch((error) => 
    {
        console.log(error);
        let route = path.resolve(`static/about.html`);
        res.sendFile(route);
    });   
});

module.exports = router;