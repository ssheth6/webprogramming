const express = require('express');
const router = express.Router();
const data = require("../data");
const path = require('path');
const eventsData = data.events;
const locationsData = data.locations;
const peopleData = data.people;

// Single Event Page
router.get("/:id", (req, res) => {
    eventsData.getEvent(Number(req.params.id)).then((eventList) => 
    {
        return eventList;
    })
    .then((eventList) => 
    {

        let allPeople = []; 
        for(let i=0; i < eventList.attendees.length; i++)
        {
            allPeople.push(peopleData.getPerson(eventList.attendees[i]).then());
        };
        return Promise.all(allPeople).then(people => 
        {
            return [eventList,people];

        });
    })
    .then((generalList) =>
    {
        return locationsData.getLocation(generalList[0].location).then(location => 
        {
            generalList.push(location.name);
            return generalList;
        });         
    })
    .then((generalList) => 
    {
        res.render('events/one', {event: generalList[0], people: generalList[1], locationName: generalList[2]});
    })
    .catch((error) => 
    {
        console.log(error);
        let route = path.resolve(`static/about.html`);
        res.sendFile(route); 
    });
});

// Event Index Page
router.get("/", (req, res) => {
    eventsData.getAllEvents().then((allEvents) => 
    {
        res.render('events/everything', {allEvents: allEvents});
    })
    .catch((error) => 
    {  
       let route = path.resolve(`static/about.html`);
        res.sendFile(route);
    });  
});

module.exports = router;

/*

*/