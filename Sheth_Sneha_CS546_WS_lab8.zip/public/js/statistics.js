(function ($, localStorage, location) 
{

    //Count the total interval timings
    var intervalInput = $("#intervals");
   
    if(!localStorage["total_iterations"])
    {
        localStorage["total_iterations"] = 0;
    }
    else
    {
        $("#intervals").children()[1].innerText = localStorage["total_iterations"];
    }    
    
    var intervalId = window.setInterval(function () 
    {
        ++localStorage["total_iterations"];
        $("#intervals").children()[1].innerText = localStorage["total_iterations"];

    }, 1500);

    $("#intervals").children()[1].innerText = localStorage["total_iterations"];
     
    //Submission of the statistics form
    if(!localStorage["form_submissions"])
    {
        localStorage["form_submissions"] = 0;
    }
    else
    {
         $("#submission_count").children()[1].innerText = localStorage["form_submissions"];
    }    
    $("form").submit(function(e)
    {
        localStorage["form_submissions"]++;
        $("#submission_count").children()[1].innerText = localStorage["form_submissions"];

    });
    

    //Finding the last input value.
    if(!localStorage["last_input"])
    {
        localStorage["last_input"] = '';
    }
    else
    {
         $("#last_input_value").children()[1].innerText = localStorage["last_input"];
    }

    $("input").keydown(function(number)
    {
        localStorage["last_input"] = number.key;
        $("#last_input_value").children()[1].innerText = localStorage["last_input"];
    });

    $("#local_storage_reset").click(function()
    {
        localStorage["total_iterations"] = 0;
        localStorage["form_submissions"] = 0;
        localStorage["last_input"] = '';
        localStorage['location_hash'] = JSON.stringify([location.hash]);

         $("#intervals").children()[1].innerText = localStorage["total_iterations"];
         $("#submission_count").children()[1].innerText = localStorage["form_submissions"];
         $("#last_input_value").children()[1].innerText = localStorage["last_input"];
         $("#location_hash_value").children()[1].innerHTML = location.hash;  
    });


    //The following function will count the hash of the location   
    if(!localStorage["location_hash"])
    {
        if(location.hash)
        {
            localStorage['location_hash'] = JSON.stringify([location.hash]);
        }
        else
        {
            localStorage['location_hash'] = JSON.stringify([]);
        }
        $("#location_hash_value td")[1].innerHTML = location.hash;
    }
    else
    {
        var loc_hash = JSON.parse(localStorage['location_hash']);
        var innerHtml = "";
        for(var i=0; i < loc_hash.length; i++)
        {
            innerHtml += loc_hash[i] + "<br/>";
        }
         $("#location_hash_value td")[1].innerHTML = innerHtml;
    }

    function locationHashChange(event)
    {
        var loc_hash = JSON.parse(localStorage['location_hash']);
        loc_hash.push(location.hash);
        var innerHtml = "";
        for(var i=0; i < loc_hash.length; i++)
        {
            innerHtml += loc_hash[i] + "<br/>";
        }
        localStorage['location_hash'] = JSON.stringify(loc_hash); 

        $("#location_hash_value td")[1].innerHTML = innerHtml;
    }
    window.addEventListener("hashchange", locationHashChange, false);

    $("#location_hash_change").click(function()
    {
        var timestamp = new Date().getTime();
        location.hash = timestamp;
    });

})(jQuery, window.localStorage, window.location);
