const statisticRoutes = require("./statistics");

const constructorMethod = (app) => 
{
    app.use("/", statisticRoutes);

    app.use("*", (req, res) => 
    {
        res.sendStatus(404);
    })
};

module.exports = constructorMethod;