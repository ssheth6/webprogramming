const mongoCollections = require("../config/mongoCollections");
const uuid = require("node-uuid");
const education = mongoCollections.education;

let educationMethods = 
{
    getEducationById(id) 
    {
        if (!id)
        {
            return Promise.reject("You must provide an id to search for");
        }
            
        return education().then((educationCollection) => 
        {
            if(!educationCollection.findOne({_id: id}) || educationCollection.findOne({_id: id}) === undefined)
            {
                return Promise.reject("Education with the given id does not exist.");
            }
            return educationCollection.findOne({_id: id});
        });
    },

    addEducation(edu)
    {
        if (!edu)
        {
            return Promise.reject("You must provide an education list to be added.");
        }
        return education().then((educationCollection) => 
        {
            let newEducation = 
            {
                _id: uuid.v4(),
                highschool: `${edu.highschool}`,
                undergrad: {
                    name: `${edu.undergrad.name}`,
                    degree: `${edu.undergrad.degree}`
                }
            };

            return educationCollection.insertOne(newEducation)
                .then((newInsertInformation) => 
                {
                    return newInsertInformation.insertedId;
                })
                .then((newId) => 
                {
                    return this.getEducationById(newId);
                });
        });
    },

    getAllEducation()
    {
        return education().then((educationCollection) => 
        {
            var myCursor = educationCollection.find();
            var educationArray = myCursor.toArray();
            if(!educationArray)
            {
                return Promise.reject("No education exists.");
            }
            return educationArray;
        });
        
    }
}

module.exports = educationMethods;