const mongoCollections = require("../config/mongoCollections");
const uuid = require("node-uuid");
const hobbies = mongoCollections.hobbies;

let hobbyMethods = 
{
    getHobbyById(id) 
    {
        if (!id)
        {
            return Promise.reject("You must provide an id to search for");
        }
            
        return hobbies().then((hobbiesCollection) => 
        {
            if(!hobbiesCollection.findOne({_id: id}) || hobbiesCollection.findOne({_id: id}) === undefined)
            {
                return Promise.reject("Hobby with the given id does not exist.");
            }
            return hobbiesCollection.findOne({_id: id});
        });
    },

    addHobbies(myHobby)
    {
        if (!myHobby)
        {
            return Promise.reject("You must provide an argument for your hobby list.");
        }
        return hobbies().then((hobbyCollection) => 
        {
            let newHobby = 
            {
                hobby: `${myHobby.hobby}`,
                description: `${myHobby.description}`, 
                _id: uuid.v4()
            };
            
            return hobbyCollection.insertOne(newHobby)
                .then((newInsertInformation) => 
                {
                    return newInsertInformation.insertedId;
                })
                .then((newId) => {
                    return this.getHobbyById(newId);
                });
        });
    },

    getAllHobbies()
    {
        return hobbies().then((hobbyCollection) => 
        {
            var myCursor = hobbyCollection.find({}, {hobby:1, _id:0});
            var hobbyArray = myCursor.toArray();
            if(!hobbyArray)
            {
                return Promise.reject("No hobbies exist.");
            }
            return hobbyArray;
        });
        
    },

    getHobbyByName(name)
    {
        if (!name)
        {
            return Promise.reject("You must provide a hobby name to search for");
        }
            
        return hobbies().then((hobbiesCollection) => 
        {
            if(!hobbiesCollection.find({hobby: name}, {description:1}) || hobbiesCollection.find({hobby: name}, {description:1}) === undefined)
            {
                return Promise.reject("Hobby with the given name does not exist.");
            }
            return hobbiesCollection.find({hobby: name}, {description:1}).toArray();
        });
    }
}

module.exports = hobbyMethods;