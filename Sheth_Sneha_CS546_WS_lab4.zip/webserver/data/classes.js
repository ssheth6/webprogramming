const mongoCollections = require("../config/mongoCollections");
const uuid = require("node-uuid");
const classes = mongoCollections.classes;

let classMethods = 
{
    getClassById(id) 
    {
        if (!id)
        {
            return Promise.reject("You must provide an id to search for");
        }
            
        return classes().then((classesCollection) => 
        {
            if(!classesCollection.findOne({_id: id}) || classesCollection.findOne({_id: id}) === undefined)
            {
                return Promise.reject("Class with the given id does not exist.");
            }
            return classesCollection.findOne({_id: id});
        });
    },

    addClasses(course)
    {
        if (!course)
        {
            return Promise.reject("You must provide an argument for your class list.");
        }
        return classes().then((classCollection) => 
        {
            let newClass = 
            {
                code: `${course.code}`,
                details: {
                    name: `${course.details.name}`,
                    professor: `${course.details.professor}`,
                    description: `${course.details.description}`
                },
                _id: uuid.v4()
            };
            
            return classCollection.insertOne(newClass)
                .then((newInsertInformation) => 
                {
                    return newInsertInformation.insertedId;
                })
                .then((newId) => {
                    return this.getClassById(newId);
                });
        });
    },

    getAllClasses()
    {
        return classes().then((classCollection) => 
        {
            var myCursor = classCollection.find({}, {code:1, _id:0});
            var classArray = myCursor.toArray();
            if(!classArray)
            {
                return Promise.reject("No classes exist.");
            }
            return classArray;
        });
        
    },

    getClassByCode(courseCode)
    {
        if (!courseCode)
        {
            return Promise.reject("You must provide a code to search for");
        }
            
        return classes().then((classCollection) => 
        {
            if(!classCollection.find({code: courseCode}, {details:1}) || classCollection.find({code: courseCode}, {details:1}) === undefined)
            {
                return Promise.reject("Course with the given code does not exist.");
            }
            return classCollection.find({code: courseCode}, {details:1}).toArray();
        });
    }
}

module.exports = classMethods;