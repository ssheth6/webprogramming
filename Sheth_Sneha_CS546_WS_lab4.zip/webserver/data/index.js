const educationData = require("./education");
const classesData = require("./classes");
const hobbiesData = require("./hobbies");

module.exports = {
    education: educationData,
    classes: classesData,
    hobbies: hobbiesData
};