const express = require('express');
const router = express.Router();
const data = require("../data");
const educationData = data.education;


router.get("/undergrad", (req, res) => 
{
    educationData.getAllEducation().then((undergradEducation) => 
    {
        res.setHeader('Content-Type', 'application/json');
        res.status(200).json({undergrad:undergradEducation[0].undergrad});

    }).catch((error) => 
    {
        // Not found!
        res.status(404).json({message: "Undergrad name and/or degree not found"});
    });
});


router.get("/highschool", (req, res) => 
{
    educationData.getAllEducation().then((highSchoolEducation) => 
    {
        res.setHeader('Content-Type', 'application/json');
        res.status(200).json({highschool:highSchoolEducation[0].highschool});

    }).catch((error) => 
    {
        // Not found!
        res.status(404).json({message: "Highschool not found"});
    });
});


router.get("/", (req, res) => 
{
    educationData.getAllEducation().then((educationList) => 
    {
        res.setHeader('Content-Type', 'application/json');
        res.status(200).json(educationList);

    }, () => 
    {
        // Something went wrong with the server!
        res.status(500).send();
    });
});

module.exports = router;