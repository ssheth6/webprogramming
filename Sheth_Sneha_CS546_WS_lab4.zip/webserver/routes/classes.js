const express = require('express');
const router = express.Router();
const data = require("../data");
const classesData = data.classes;

router.get("/details", (req, res) => 
{
    classesData.getClassByCode(req.query.code).then((courseList) => 
    {
        res.setHeader('Content-Type', 'application/json');
        res.status(200).json(courseList);

    }).catch((error) => 
    {
        // Not found!
        res.status(404).json({message: "Class not found"});
    });
});

router.get("/", (req, res) => 
{
    classesData.getAllClasses().then((courseList) => 
    {
        res.setHeader('Content-Type', 'application/json');
        res.status(200).json(courseList);
        
    }, () => 
    {
        // Something went wrong with the server!
        res.status(500).send();
    });
});

module.exports = router;