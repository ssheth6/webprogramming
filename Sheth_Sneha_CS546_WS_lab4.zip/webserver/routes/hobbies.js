const express = require('express');
const router = express.Router();
const data = require("../data");
const hobbiesData = data.hobbies;

router.get("/:hobby", (req, res) => 
{
    hobbiesData.getHobbyByName(req.params.hobby).then((hobbyList) => 
    {

        res.setHeader('Content-Type', 'application/json');
        res.status(200).json(hobbyList);

    }).catch((error) => 
    {
        // Not found!
        res.status(404).json({message: "Hobby not found"});
    });
});

router.get("/", (req, res) => 
{
    hobbiesData.getAllHobbies().then((hobbyList) => 
    {
        res.setHeader('Content-Type', 'application/json');
        res.status(200).json(hobbyList);

    }, () => 
    {
        // Something went wrong with the server!
        res.status(500).send();
    });
});

module.exports = router;