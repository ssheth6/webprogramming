const dbConnection = require("../config/mongoConnection");
const data = require("../data/");
const education = data.education;
const hobbies = data.hobbies;
const classes = data.classes;

dbConnection().then(db => 
{
    return db.dropDatabase()
    .then(() => 
    {
        return dbConnection;
    })
    .then((db) => 
    {
        var edu = '{"highschool": "Navrachana", "undergrad": {"name": "LDRP", "degree": "Bachelor of Engineering in Computer Engineering"}}';
        return education.addEducation(JSON.parse(edu));
    })
    .then((db) => 
    {
        var course1 = '{"code": "CS-561", "details": {"name": "Database Management Systems I", "professor": "Prof. Samuel Kim", "description": "The course deals with basic database management systems."}}';
        return classes.addClasses(JSON.parse(course1));
    })
    .then((db) => 
    {
        var course2 = '{"code": "CS-562", "details": {"name": "Database Management Systems II", "professor": "Prof. Samuel Kim", "description": "The course deals with advanced database management systems."}}';
        return classes.addClasses(JSON.parse(course2));
    })
    .then((db) => 
    {
        var course3 = '{"code": "CS-546", "details": {"name": "Web Programming", "professor": "Prof. Philip Barresi", "description": "The course deals with web programming skills."}}';
        return classes.addClasses(JSON.parse(course3));
    })
    .then((db) => 
    {
        var hobby1 = '{"hobby": "Reading", "description": "I like to read mystery and romantic novels."}';
        return hobbies.addHobbies(JSON.parse(hobby1));
    })
    .then((db) => 
    {
        var hobby2 = '{"hobby": "Traveling", "description": "I like to travel to quiet places like museums and art galleries."}';
        return hobbies.addHobbies(JSON.parse(hobby2));
    })
    .then(() => 
    {
        console.log("Done seeding database");
        db.close();
    });
}, 
(error) => 
{
    console.error(error);
});